document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector(".form");
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const messageInput = document.getElementById("message");
    const captchaInput = document.getElementById("captcha");
    const nameError = document.getElementById("name-error");
    const emailError = document.getElementById("email-error");
    const messageError = document.getElementById("message-error");
    const captchaAnswer = 7; // Answer for "3 + 4?"

    // Utility function to show error
    const showError = (input, errorElement, message) => {
        input.classList.add("error-border");
        errorElement.textContent = message;
        errorElement.style.display = "block";
    };

    // Utility function to hide error
    const hideError = (input, errorElement) => {
        input.classList.remove("error-border");
        errorElement.style.display = "none";
    };

    // Name Validation
    nameInput.addEventListener("input", () => {
        if (nameInput.value.trim() === "") {
            showError(nameInput, nameError, "Name is required.");
        } else {
            hideError(nameInput, nameError);
        }
    });

    // Email Validation
    emailInput.addEventListener("input", () => {
        const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
        if (!emailInput.value.match(emailPattern)) {
            showError(emailInput, emailError, "Please enter a valid email address.");
        } else {
            hideError(emailInput, emailError);
        }
    });

    // Message Validation
    messageInput.addEventListener("input", () => {
        if (messageInput.value.trim().length < 10) {
            showError(messageInput, messageError, "Message must be at least 10 characters.");
        } else {
            hideError(messageInput, messageError);
        }
    });

    // Form Submission
    form.addEventListener("submit", (event) => {
        let isValid = true;

        // Validate Name
        if (nameInput.value.trim() === "") {
            showError(nameInput, nameError, "Name is required.");
            isValid = false;
        }

        // Validate Email
        const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
        if (!emailInput.value.match(emailPattern)) {
            showError(emailInput, emailError, "Please enter a valid email address.");
            isValid = false;
        }

        // Validate Message
        if (messageInput.value.trim().length < 10) {
            showError(messageInput, messageError, "Message must be at least 10 characters.");
            isValid = false;
        }

        // Validate CAPTCHA
        if (parseInt(captchaInput.value.trim()) !== captchaAnswer) {
            alert("Incorrect CAPTCHA answer. Please try again.");
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });
});
